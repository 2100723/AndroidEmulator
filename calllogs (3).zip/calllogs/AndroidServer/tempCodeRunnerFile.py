from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'C:\\Users\\leech\\Desktop\\University\\year2-tri2\\2207\\calllogs\\uploads'
app.config['ALLOWED_EXTENSIONS'] = {'txt', 'csv'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in app.config['ALLOWED_EXTENSIONS']

@app.route('/uploads', methods=['POST'])
def handle_call_logs():
    if request.method == 'POST':
        file = request.files['call_log']
        if file:
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            return jsonify({'status': 'success'})
        else:
            return jsonify({'status': 'failed'})
    else:
        return jsonify({'status': 'Invalid request method'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
