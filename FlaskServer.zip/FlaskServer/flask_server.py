import flask
import werkzeug
import time

app = flask.Flask(__name__)

@app.route('/', methods = ['GET', 'POST'])
def handle_request():
    image_paths = []
    files_ids = list(flask.request.files)
    print("\nNumber of Received Images : ", len(files_ids))
    image_num = 1
    for file_id in files_ids:
        print("\nSaving Image ", str(image_num), "/", len(files_ids))
        imagefile = flask.request.files[file_id]
        filename = werkzeug.utils.secure_filename(imagefile.filename)
        print("Image Filename : " + imagefile.filename)
        timestr = time.strftime("%Y%m%d-%H%M%S")
        file_path = timestr+'_'+filename
        imagefile.save(file_path)
        image_paths.append(file_path)
        image_num = image_num + 1
    print("\n")
    return flask.render_template('image_template.html', images=image_paths)


app.run(host="0.0.0.0", port=5000, debug=True)