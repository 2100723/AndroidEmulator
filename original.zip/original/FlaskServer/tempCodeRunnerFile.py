import flask
from flask import Flask, render_template, send_from_directory
import os

app = Flask(__name__, template_folder='C:\\Users\\leech\\Desktop\\University\\year2-tri2\\2207\\original\\templates')
app.config['UPLOAD_FOLDER'] = 'C:\\Users\\leech\\Desktop\\University\\year2-tri2\\2207\\original\\image'

@app.route('/', methods = ['GET'])
def index():
    image_filenames = os.listdir(app.config['UPLOAD_FOLDER'])
    return render_template('index.html', image_filenames=image_filenames)

@app.route('/images/<filename>')
def serve_image(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)
 if flask.request.method == 'GET':
        print("Handling GET request")
        image_filenames = os.listdir(r"C:\Users\leech\Desktop\University\year2-tri2\2207\original\image")
        return flask.render_template('index.html', image_filenames=image_filenames)
    else:
        return "Method not allowed", 405

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)