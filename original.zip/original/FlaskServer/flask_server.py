from flask import Flask, flash, request, redirect, url_for, render_template
from flask import send_from_directory
import os

app = Flask(__name__, template_folder='C://Users//leech//Desktop//University//year2-tri2//2207//original//templates')
app.secret_key = "your_secret_key"

image_folder = os.path.join("C:\\","Users","leech","Desktop","University","year2-tri2","2207","original","image")  # directory where you want to save the images
app.config['UPLOAD_FOLDER'] = image_folder

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'image' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['image']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file:
            filename = file.filename
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            flash('File(s) uploaded successfully')
    image_filenames = os.listdir(app.config['UPLOAD_FOLDER'])
    return render_template('index.html', image_filenames=image_filenames)

@app.route('/images/<filename>')
def serve_image(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)